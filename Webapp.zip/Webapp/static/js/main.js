document.addEventListener('DOMContentLoaded', function () {
    // Your JavaScript code goes here
});
