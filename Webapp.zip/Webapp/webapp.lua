/your-web-app
  |-- static
      |-- css
          |-- style.css
      |-- js
          |-- main.js
  |-- templates
      |-- index.html
  |-- app.py
